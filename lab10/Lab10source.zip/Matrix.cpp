//course: CS216-00x
//Project: Lab Assignment 10
//Date: 11/08/2016
//File: Matrix.cpp
//Purpose: to define the class Matrix
//Author: (your name)

#include <iostream>
#include <cassert>
#include "Matrix.h"

using namespace std;

Matrix::Matrix(int sizeX, int sizeY) : dx(sizeX), dy(sizeY)
{
	assert(sizeX > 0 && sizeY > 0);
	p = new long*[dx];		
				// create array of pointers to long integers
	assert(p != 0);
	for (int i = 0; i < dx; i++)
	{	  // for each pointer, create array of long integers
		p[i] = new long[dy];  
		assert(p[i] != 0);
		for (int j = 0; j < dy; j++)
			p[i][j] = 0;
	}
}

Matrix::~Matrix()
{
	for (int i = 0; i < dx; i++)
		delete [] p[i];	// delete arrays of long integers
	delete [] p;	// delete array of pointers to long
}

long &Matrix::Element(int x, int y)
{
	assert(x >= 0 && x < dx && y >= 0 && y < dy);
	return p[x][y];
}

void Matrix::Print() const
{
	for (int x = 0; x < dx; x++)
	{
		for (int y = 0; y < dy; y++)
			cout << p[x][y] << "\t";
		cout << endl;
	}
}



