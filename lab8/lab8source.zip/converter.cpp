//converter.cpp

#include <iostream>
#include "converter.h"
#include "stack.h"

bool isOperand(char op)
{
    if (op == '+' || op == '-' || op == '*' || op == '/' || op == '(' || op == ')')
        return false;
    return true;
}

int precedence(char op)
{
    if (op == '*' || op == '/')
        return HIGHPRECEDENCE;
    if (op == '+' || op == '-')
        return LOWPRECEDENCE;
    return -1;
}

string infix_to_postfix(string Ei)
{
    // your code starts here
}

bool valid_parentheses(string E)
{
    stack S;
    for(int i = 0; i < E.length(); i++)
    {
        if (E[i] == '(')
            S.push(E[i]);
        if (E[i] == ')')
            S.pop();
    }   
    return S.isEmpty();
}
