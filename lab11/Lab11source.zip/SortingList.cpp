/* File:   SortingList.cpp
 * Purpose: to provide the definition of the class named SortingList
 *          it stores a sequence of objects to perform sorting operation
 * Author: <your name>
 *
 */
#include <cassert>
#include "SortingList.h"

SortingList::SortingList()
{
    capacity = INITIAL_CAPACITY;
    size = 0;
    p = new string[capacity];	// create a dynamic array of string objects
    assert(p != NULL);
}

SortingList::SortingList(int incapacity)
{
	assert(incapacity > 0);
        capacity = incapacity;
	p = new string[capacity];	// create a dynamic array of string objects
	assert(p != NULL);
        size = 0;
}

SortingList::SortingList(const SortingList &other) : capacity(other.capacity), size(other.size)
{
	p = new string[capacity];            // create array of base type objects
	assert(p != 0);
	for (int i = 0; i < size; i++)
	{
            p[i] = other.p[i];
	}
}


SortingList::~SortingList()
{
	delete [] p;	// release the dynamic array
}


void SortingList::insertAtTail(string item)
{
    size = size + 1;
    if (size >= capacity) 
    {
        // No more room:  allocate more.
        capacity *= 2;
        string* copy = new string[capacity];
        assert(copy != NULL);
        // Copy over the data
        for (int i = 0; i < size; i++)
            copy[i] = p[i];
        // Free the old copy and point to the new one.
        delete[] p;
        p = copy;
    }
    // insert at the back of the list
    // Note that the size has been increased one at the beginning
    // size represents the size after inserting the new item
    p[size-1] = item;   
}

string &SortingList::Element(int x)
{
	assert(x >= 0 && x < size);
	return p[x];
}

void SortingList::Print() const
{
	for (int x = 0; x < size; x++)
	{
            cout << p[x] << endl;
	}
}

SortingList &SortingList::operator=(const SortingList &other)
{
	if (this != &other)
	{
		assert(size == other.size);
		for (int i = 0; i < size; i++)
                    p[i] = other.p[i];
	}
	return *this;
}

void SortingList::bubble_sort()
{
    string temp; //for swapping
    for (int i = 0 ; i < size-1 ; i++)
    {
        for (int j = 0 ; j < size-1 ; j++)
        {
            if ( p[j] > p[j + 1] )
            {
                temp = p[j];
                p[j]=p[j + 1];
                p[j + 1] = temp;
            }
        }
    }
}    

